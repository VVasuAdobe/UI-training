ENGLISH
Product Usage Agreement:

1. By installing or using this font, I AGREE TO FOLLOW ALL THESE RULES

2. This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
But any donation is very appreciated. Paypal account for donation https://www.paypal.me/JavaPep

3. You must have a license for PROMOTIONAL or COMMERCIAL USE.

4. For getting commercial license, please visit https://javapep.com/

CONATCT SUPPORT:
java.indonesian@yahoo.com

-------------------

INDONESIA:

Perjanjian Penggunaan Produk:

1. Dengan menginstal atau menggunakan font ini, SAYA SETUJU UNTUK MENGIKUTI SEMUA ATURAN INI.

2. Font ini HANYA untuk PENGGUNAAN PRIBADI, BUKAN UNTUK PENGGUNAAN KOMERSIAL atau bersifat menghasilkan uang.

3. Anda harus memiliki IJIN dari saya untuk PENGGUNAAN KOMERSIAL atau yang bersifat menghsilkan uang.

4. SILAHKAN HUBUNGI SAYA untuk Penggunaan Promosi atau Komersial, untuk HARGA BISA NEGOSIASI.

5. Bila kedapatan menggunakan font ini untuk KOMERSIL tanpa LISENSI/IJIN dari saya, maka anda secara tidak langsung saya setuju untuk membayar biaya DENDA 100 kali lipat dari harga Lisensi Standart.

Silahkan hubungi saya untuk informasi jensi Lisensi apa yang diperlukan di:
Email: java.indonesian@yahoo.com    

